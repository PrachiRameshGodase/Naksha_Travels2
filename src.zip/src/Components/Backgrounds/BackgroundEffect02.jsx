import React from 'react'

const BackgroundEffect02 = () => {
  return (
    <div id='backgorundeffect02'>
  <section>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
    <span></span>
  </section>
    </div>
  )
}

export default BackgroundEffect02

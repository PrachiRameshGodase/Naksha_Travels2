import React from 'react'

const MainScreenFreezeLoader = () => {
  return (
    <div id='mainscreenfreezeloader'>
     <div className="contackn45sd6f">
     <div className="data-loader">
	<div>
		<div></div>
		<div></div>
		<div></div>
		<div></div>
	</div>
</div>
     </div>
    </div>
  )
}

export default MainScreenFreezeLoader

import React from 'react'

const Loader02 = () => {
  return (
    <div id='loader02'>
        {/* <div className="darksoul-layout">
        <div className="darksoul-grid">
            <div className="item1"></div>
            <div className="item2"></div>
            <div className="item3"></div>
            <div className="item4"></div>
        </div>
        <h3 className="darksoul-loader-h">Loading...</h3>
    </div> */}
    </div>
  )
}

export default Loader02

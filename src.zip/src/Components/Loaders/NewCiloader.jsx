import React from 'react'

const NewCiloader = () => {
  return (
    <>
      <div id="loadingsdf5-bar-spinner" className="spinner"><div className="spinner-icon"></div></div>
    </>
  )
}

export default NewCiloader

import React from 'react'

const MailsOfCustomer = ({user}) => {
  return (
    <div>
      MailsOfCustomer
    </div>
  )
}

export default MailsOfCustomer

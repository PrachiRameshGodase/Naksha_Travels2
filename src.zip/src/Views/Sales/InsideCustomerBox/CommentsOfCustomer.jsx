import React from 'react'

const CommentsOfCustomer = ({user}) => {
  return (
    <div>
      comments
    </div>
  )
}

export default CommentsOfCustomer

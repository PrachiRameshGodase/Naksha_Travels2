import React from 'react'

const DashboardComponent = () => {
  return (
    <>
      {/* <p>Dashboard Content</p> */}
    </>
  )
}

export default DashboardComponent

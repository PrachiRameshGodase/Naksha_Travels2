export const withPurchaseOrder = [

    {
        "id": 1,
        "labelid": 1,
        "label": "Yes",
    },
    {
        "id": 2,
        "labelid": 2,
        "label": "No",
    }

]

export const GRNype = [
    {
        "id": 1,
        "labelid": "Local",
        "label": "Local",
    },
    {
        "id": 2,
        "labelid": "Import",
        "label": "Import",
    },

]

export const warehouse_type = [
    {
        "id": 1,
        "labelid": "Regular",
        "label": "Regular",
    },
    {
        "id": 2,
        "labelid": "Container",
        "label": "Container",
    },
    {
        "id": 3,
        "labelid": "Silo",
        "label": "Silo",
    },

]

export const warehouse_department = [
    {
        "id": 1,
        "labelid": "Department1",
        "label": "Department1",
    },
    {
        "id": 2,
        "labelid": "Department2",
        "label": "Department2",
    },

]

export const warehouse_for = [
    {
        "id": 1,
        "labelid": "Production",
        "label": "Production",
    },
    {
        "id": 2,
        "labelid": "Non-Production",
        "label": "Non-Production",
    },

]

export const helpPriority = [
    {
        "id": 1,
        "labelid": "High",
        "label": "High",
    },
    {
        "id": 2,
        "labelid": "Medium",
        "label": "Medium",
    },
    {
        "id": 3,
        "labelid": "Low",
        "label": "Low",
    },

]

export const helpStatus = [
    {
        "id": 1,
        "labelid": 1,
        "label": "Pending",
    },
    {
        "id": 2,
        "labelid": 2,
        "label": "In Progress",
    },
    {
        "id": 3,
        "labelid": 3,
        "label": "Resolved",
    },

]

// export const zone_type = [
//     {
//         "id": 1,
//         "labelid": "Regular",
//         "label": "Regular",
//     },
//     {
//         "id": 2,
//         "labelid": "Container",
//         "label": "Container",
//     },

// ]
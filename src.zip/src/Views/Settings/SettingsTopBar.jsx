import React from 'react'

const SettingsTopBar = () => {
  return (
    <>
      
    </>
  )
}

export default SettingsTopBar

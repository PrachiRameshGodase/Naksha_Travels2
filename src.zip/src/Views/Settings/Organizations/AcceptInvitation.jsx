import React from 'react'

const AcceptInvitation = () => {
  return (
    <>
      /api/organisation/invitation/login
    </>
  )
}

export default AcceptInvitation

